#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface Zone1110 : NSObject
NS_ASSUME_NONNULL_BEGIN
- (void)setToken:(NSString *)token;
- (void)paid:(void (^)(void))execute;
- (NSString *)getKey;
- (NSString *)deviceType;
- (NSString *)iOSVersion;
- (NSString *)getUDID;
extern NSString * const __contact;
extern NSString * const __Confirm;
@end
NS_ASSUME_NONNULL_END